module Libv8
  VERSION = "6.3.292.48.1"
end
